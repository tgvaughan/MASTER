#!/bin/bash

ONEJAR=MASTER-1.0.jar

SCRIPTPATH=$(readlink -f $0)

if [ -z "$SCRIPTPATH" ]; then
    MASTERDIR=$PWD
else
    MASTERDIR=$(dirname "$SCRIPTPATH")
fi

java -jar "$MASTERDIR"/$ONEJAR $@


